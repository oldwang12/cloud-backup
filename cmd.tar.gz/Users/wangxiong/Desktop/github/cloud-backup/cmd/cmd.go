package cmd

import "github.com/oldwang12/cloud-backup/cmd/github"

func Execute() {
	github.Command.Execute()
}
