package main

import (
	"fmt"
	"os"
	"path/filepath"
)

func main() {
	directory := "." // 将此处替换为目录路径

	err := filepath.Walk(directory, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if !info.IsDir() {
			fmt.Println(path)
		}

		return nil
	})

	if err != nil {
		fmt.Println("Error:", err)
		return
	}
}
